#include <iostream>

#include "dialogue.h"

using namespace std;

int main()
{
    dialogue();
    return 0;
}