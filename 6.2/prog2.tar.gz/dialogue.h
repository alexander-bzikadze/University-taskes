#pragma once

#include <iostream>

#include "list.h"

void greeting();

void enterCommand(int & command);

void addValue(List & sortedList);

void deleteValue(List & sortedList);

void seeOut(List sortedList);

int dialogue();